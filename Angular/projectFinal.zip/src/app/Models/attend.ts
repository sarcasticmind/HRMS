import { Time } from "@angular/common";

export class Attend{
   id=0;
    empId : number;
    attendingTime : string = ''
    leavingTime : string = ''
    day ='';
}
