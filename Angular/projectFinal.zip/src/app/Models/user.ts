export class UserLogin {
  email: string = '';
  password: string = '';
}

export class UserRegister {
  User_id :number = 0;
  User_Email : string ='';
  User_Password: string = '';
  User_Name: string = '';
}
