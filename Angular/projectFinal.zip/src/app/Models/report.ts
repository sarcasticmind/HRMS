export class Report{
  name =''
salary =0;
numberOfAttendingDays =0;
numberOfAbsanceDays =0;
extraInhours =0;
penalityInhours =0;
extraInPounds =0;
penaityInPunds =0;
finalSalary =0;
}
