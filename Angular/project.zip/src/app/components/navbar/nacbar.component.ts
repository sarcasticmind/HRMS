import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nacbar',
  templateUrl: './nacbar.component.html',
  styleUrls: ['./nacbar.component.css'],
})
export class NacbarComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
